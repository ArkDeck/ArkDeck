"""Small fixture and typed range regressions; never default target-size I/O."""
import base64
import gzip
import hashlib
import io
import pathlib
import subprocess
import tarfile
import tempfile
import unittest
from unittest.mock import Mock, patch
from . import artifact, artifact_fixture, metrics
from .test_compare import document, scaled
from . import compare


def receipt(data=b'abcd'):
    return {'owner': {'kind': 'import', 'id': 'imp-test'}, 'artifactId': 'ART-fixture',
            'artifactDigest': hashlib.sha256(data).hexdigest()}


def page(data=b'abcd', offset=0, total=4):
    return {'artifactId': 'ART-fixture', 'artifactDigest': receipt()['artifactDigest'],
            'base64': base64.b64encode(data).decode(), 'byteCount': len(data),
            'offset': offset, 'nextOffset': offset+len(data), 'totalByteCount': total,
            'eof': offset+len(data)==total}


class ArtifactFixtureTests(unittest.TestCase):
    def test_small_fixture_exact_stream_digest_and_existing_member_set(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory)/'fixture.tar.gz'
            facts = artifact_fixture.generate(path, 1024*1024)
            data = path.read_bytes()
            self.assertEqual(len(data), 1024*1024)
            self.assertEqual(hashlib.sha256(data).hexdigest(), facts['sha256'])
            # Only the 1 MiB correctness scale is decompressed in this test.
            with tarfile.open(fileobj=io.BytesIO(gzip.decompress(data)), mode='r:') as archive:
                self.assertEqual(len(archive.getmembers()), 17)
                self.assertEqual(archive.getmember('userdata.img').size, facts['userdataBytes'])
                self.assertIn(b'const.ohos.fullname=', archive.extractfile('system.img').read())
            with self.assertRaises(FileExistsError):
                artifact_fixture.generate(path, 1024*1024)

    def test_invalid_scale_refuses_before_writing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = pathlib.Path(directory)/'fixture.tar.gz'
            with self.assertRaises(ValueError):
                artifact_fixture.generate(path, 1024)
            self.assertFalse(path.exists())

    def test_reserve_includes_three_copies_plus_four_gib(self):
        count = 128*1024*1024
        with patch.object(artifact.shutil, 'disk_usage', return_value=Mock(free=4*1024**3+2*count)):
            with self.assertRaises(ValueError):
                artifact.check_disk('/fixture', count)


class ArtifactRangeTests(unittest.TestCase):
    def test_exact_full_and_partial_ranges(self):
        self.assertEqual(artifact.validate_page(page(), receipt(), 0, 4), b'abcd')
        self.assertEqual(artifact.validate_page(page(b'ab', 0, 4), receipt(), 0, 4), b'ab')

    def test_wrong_identity_digest_offsets_counts_eof_and_encoding_refuse(self):
        changes = [('artifactId','wrong'),('artifactDigest','0'*64),('byteCount',True),
                   ('byteCount',3),('offset',1),('nextOffset',3),('totalByteCount',5),
                   ('eof',False),('eof',1),('base64','not-base64'),('base64','YWJjZA==='),
                   ('base64','YWJjZA==é'),('base64','YWJj\nZA==')]
        for key,value in changes:
            candidate = page(); candidate[key] = value
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                artifact.validate_page(candidate, receipt(), 0, 4)
        candidate = page(); candidate['extra'] = 1
        with self.assertRaises(ValueError):
            artifact.validate_page(candidate, receipt(), 0, 4)

    def test_canonical_encoding_across_chunk_boundaries_and_final_padding(self):
        alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
        for size in (48*1024-1, 48*1024, 48*1024+1, 48*1024+2, 2*48*1024+1):
            data = (bytes(range(256))*((size+255)//256))[:size]
            candidate = page(data, total=size)
            self.assertEqual(artifact.validate_page(candidate, receipt(), 0, size), data)
            if size % 3:
                text = candidate['base64']
                position = -3 if size % 3 == 1 else -2
                index = alphabet.index(text[position])
                candidate['base64'] = text[:position] + alphabet[index+1] + text[position+1:]
                # Strict decoding alone accepts nonzero unused padding bits.
                self.assertEqual(base64.b64decode(candidate['base64'], validate=True), data)
                with self.assertRaisesRegex(ValueError, 'encoding'):
                    artifact.validate_page(candidate, receipt(), 0, size)

    def test_extra_base64_padding_after_complete_chunk_refuses(self):
        data = b'x'*(48*1024)
        candidate = page(data, total=len(data))
        candidate['base64'] += '===='
        with self.assertRaises(ValueError):
            artifact.validate_page(candidate, receipt(), 0, len(data))

    def test_canonical_reencoding_never_materializes_another_full_page(self):
        data = b'x'*(4*1024*1024)
        candidate = page(data, total=len(data))
        encode = base64.b64encode
        sizes = []
        def bounded(chunk):
            sizes.append(len(chunk))
            return encode(chunk)
        with patch.object(artifact.base64, 'b64encode', side_effect=bounded):
            self.assertEqual(artifact.validate_page(candidate, receipt(), 0, len(data)), data)
        self.assertEqual(sum(sizes), len(data))
        self.assertLessEqual(max(sizes), 48*1024)

    def test_missing_rss_does_not_become_zero_or_peak_claim(self):
        result = artifact.rss_summary([{'unmeasured':'ps failed'}])
        self.assertIn('unmeasured', result['daemonBytes'])

    def test_failed_publication_preserves_process_facts_and_cleans_private_root(self):
        record = Mock()
        root = pathlib.Path('/fixture')
        with patch.object(artifact.harness, 'temporary_state_directory', return_value=root), \
             patch.object(artifact, 'check_disk', return_value={}), \
             patch.object(artifact_fixture, 'generate', return_value={'sha256':'a'*64}), \
             patch.object(artifact.subprocess, 'run', return_value=subprocess.CompletedProcess([], 9, '', 'validator refused')), \
             patch.object(artifact.shutil, 'rmtree') as cleanup:
            with self.assertRaises(ValueError):
                artifact.measure('/daemon', '/soak', 1024*1024, record, False)
            cleanup.assert_called_once_with(root)
        entries = [call.args[0] for call in record.call_args_list]
        process = next(e for e in entries if e['kind']=='artifactSeedProcess')
        self.assertEqual(process['returnCode'], 9)
        self.assertEqual(process['stderr']['text'], 'validator refused')
        self.assertEqual(entries[-1]['status'], 'FAILED')

    def test_changed_scale_or_boundary_refuses_comparison(self):
        fields = {'artifactReaderVersion':artifact.READER_VERSION, 'artifactArchiveSha256':'a'*64, 'artifactTemplateSha256':'b'*64,
                  'artifactPayloadBytes':128*1024*1024, 'artifactOwnerKind':'import',
                  'artifactImportKind':'flash-bundle', 'artifactPageBytes':4*1024*1024,
                  'artifactTimingBoundary':artifact.TIMING, 'artifactFixtureVersion':artifact_fixture.VERSION,
                  'artifactRssIntervalSeconds':.2, 'artifactCachePolicy':'fresh-owner-first-read-no-OS-cache-eviction'}
        for field in fields:
            other = dict(fields); other[field] = 'c'*64 if field.endswith('Sha256') else 'different'
            result = compare.compare(scaled(document(a=1), fields), scaled(document(a=1), other))
            self.assertFalse(result['passed'], field)

    def test_default_context_never_enables_large_io(self):
        context = metrics.RunContext(daemon_executable=pathlib.Path('/daemon'),
            soak_executable=pathlib.Path('/soak'), cold_start_samples=1, ipc_samples=1,
            idle_seconds=1, calibration_samples=1, seed_seconds=1, seed_jobs_per_cycle=1)
        self.assertEqual(context.artifact_samples, 0)


class RealArtifactOwnerTests(unittest.TestCase):
    def test_small_real_owner_publication_and_typed_read(self):
        import os
        daemon = os.environ.get('BENCH_TEST_DAEMON')
        soak = os.environ.get('BENCH_TEST_ARTIFACT_SOAK')
        if not daemon or not soak:
            self.skipTest('set BENCH_TEST_DAEMON and BENCH_TEST_ARTIFACT_SOAK for opt-in 1 MiB integration')
        observations = []
        elapsed, proof = artifact.measure(daemon, soak, 1024*1024, observations.append, False)
        self.assertGreater(elapsed, 0)
        self.assertEqual(proof['artifactOwnerKind'], 'import')
        self.assertEqual(proof['artifactArchiveSha256'], proof['artifactEvidence']['sha256'])
        self.assertEqual(proof['artifactTemplateSha256'], proof['artifactEvidence']['templateSha256'])
        self.assertEqual(proof['artifactEvidence']['payloadBytes'], 1024*1024)
        self.assertEqual(proof['artifactEvidence']['actualPageCount'], 1)
        self.assertTrue(any(row['kind']=='artifactReadComplete' for row in observations))


class ArtifactTransportTests(unittest.TestCase):
    def client(self, chunks, deadline=None):
        from . import control
        client = control.ControlClient('/fixture')
        client._socket = Mock()
        client._socket.recv.side_effect = chunks
        client.configure_measurement(deadline, capture_failure=True)
        return client

    def test_truncated_and_invalid_json_preserve_received_bytes_after_close(self):
        for chunks in ([b'{"id":', b''], [b'not-json\n'], [b'{}\n']):
            client = self.client(chunks)
            with self.assertRaises(Exception):
                client._exchange({'id':'test'})
            client.close()
            raw = b''.join(chunks)
            evidence = client.failure_evidence
            self.assertEqual(evidence['receivedByteCount'], len(raw))
            self.assertEqual(evidence['receivedSha256'], hashlib.sha256(raw).hexdigest())
            self.assertEqual(base64.b64decode(evidence['prefixBase64']), raw)

    def test_progressing_fragments_cannot_extend_total_deadline(self):
        from . import control
        deadline = Mock(budget_seconds=1)
        deadline.remaining_seconds.side_effect = [1., .8, .5, .2, -.1, -.1]
        client = self.client([b'a', b'b', b'never'], deadline)
        with self.assertRaisesRegex(control.ControlError, 'deadline'):
            client._exchange({'id':'test'})
        self.assertEqual(client._socket.recv.call_count, 2)
        self.assertEqual(client.failure_evidence['receivedByteCount'], 2)
        self.assertEqual(client.failure_evidence['phase'], 'receive')

    def test_failure_prefix_is_bounded_but_hash_covers_all_received_bytes(self):
        raw = b'x'*65536+b'y'*65536
        client = self.client([raw[:65536], raw[65536:], b''])
        with self.assertRaises(Exception):
            client._exchange({'id':'test'})
        facts = client.failure_evidence
        self.assertEqual(facts['receivedByteCount'], len(raw))
        self.assertEqual(facts['receivedSha256'], hashlib.sha256(raw).hexdigest())
        self.assertEqual(len(base64.b64decode(facts['prefixBase64'])), 65536)
        self.assertTrue(facts['truncated'])

    def test_transport_timeout_preserves_partial_frame(self):
        client = self.client([b'{', TimeoutError('idle')])
        with self.assertRaises(Exception):
            client._exchange({'id':'test'})
        self.assertEqual(client.failure_evidence['receivedByteCount'], 1)


class ArtifactReadLoopTests(unittest.TestCase):
    def runtime(self, response):
        from unittest.mock import MagicMock
        runtime = Mock()
        client = MagicMock()
        client.__enter__.return_value = client
        client.failure_evidence = None
        client.call.return_value = response
        runtime.client.return_value = client
        return runtime, client

    def test_final_digest_failure_retains_page_and_stops_sampler(self):
        candidate = page(b'zzzz')
        runtime, client = self.runtime(candidate)
        rows = []
        with patch.object(artifact, 'RssSampler') as sampler:
            sampler.return_value.stop.return_value = []
            with self.assertRaisesRegex(ValueError, 'final digest'):
                artifact.read_all(runtime, receipt(), 4, rows.append)
            sampler.return_value.stop.assert_called_once()
        self.assertTrue(any(r['kind']=='artifactPage' for r in rows))
        # Regression for the real second smoke failure: offset is a JSON number.
        self.assertIs(type(client.call.call_args.args[1]['offset']), int)

    def test_expired_budget_sends_no_page_and_stops_sampler(self):
        runtime, client = self.runtime(page())
        with patch.object(artifact, 'RssSampler') as sampler, patch.object(artifact.clocks, 'Deadline') as deadline:
            deadline.return_value.expired.return_value = True
            sampler.return_value.stop.return_value = []
            with self.assertRaises(TimeoutError):
                artifact.read_all(runtime, receipt(), 4, lambda row: None)
            client.call.assert_not_called()
            sampler.return_value.stop.assert_called_once()

    def test_publication_timeout_preserves_partial_output_and_cleans_root(self):
        root = pathlib.Path('/fixture'); rows=[]
        with patch.object(artifact.harness, 'temporary_state_directory', return_value=root), \
             patch.object(artifact, 'check_disk', return_value={}), \
             patch.object(artifact_fixture, 'generate', return_value={'sha256':'a'*64}), \
             patch.object(artifact.subprocess, 'run', side_effect=subprocess.TimeoutExpired('soak',600,output=b'partial',stderr=b'error')), \
             patch.object(artifact.shutil, 'rmtree') as cleanup:
            with self.assertRaises(subprocess.TimeoutExpired):
                artifact.measure('/daemon','/soak',1024*1024,rows.append,False)
            cleanup.assert_called_once_with(root)
        process=next(row for row in rows if row['kind']=='artifactSeedProcess')
        self.assertTrue(process['timedOut'])
        self.assertEqual(process['stdout']['text'],'partial')


class IncrementalArtifactTransportTests(ArtifactTransportTests):
    def test_valid_response_across_arbitrary_fragment_boundaries(self):
        import json
        response = {'id':'read-1','ok':True,'result':page()}
        wire = json.dumps(response).encode()+b'\n'
        for fragments in ([wire], [wire[:-1],wire[-1:]],
                          [wire[i:i+1] for i in range(len(wire))],
                          [wire[:37],wire[37:83],wire[83:]]):
            with self.subTest(sizes=[len(chunk) for chunk in fragments]):
                client = self.client(fragments)
                self.assertEqual(client._exchange({'id':'read-1'}),response)
                self.assertIsNone(client.failure_evidence)

    def test_oversize_response_refuses_even_if_valid_json_terminates(self):
        from . import control
        wire=b'{"id":"test","ok":true,"result":"'+b'x'*100+b'"}\n'
        client=self.client([wire[:50],wire[50:]])
        with patch.object(control,'MAXIMUM_RESPONSE_BYTES',64):
            with self.assertRaisesRegex(control.ControlError,'transport limit'):
                client._exchange({'id':'test'})
        self.assertEqual(client.failure_evidence['receivedByteCount'],len(wire))
        self.assertEqual(client.failure_evidence['receivedSha256'],hashlib.sha256(wire).hexdigest())

    def test_exact_transport_bound_includes_terminator(self):
        from . import control
        import json
        response = {'id':'test', 'ok':True, 'result':'edge'}
        wire = json.dumps(response).encode()+b'\n'
        for bound in (len(wire), len(wire)-1):
            client = self.client([wire[:-1], wire[-1:]])
            with patch.object(control, 'MAXIMUM_RESPONSE_BYTES', bound):
                if bound == len(wire):
                    self.assertEqual(client._exchange({'id':'test'}), response)
                    self.assertEqual(client._socket.recv.call_count, 2)
                else:
                    with self.assertRaisesRegex(control.ControlError, 'transport limit'):
                        client._exchange({'id':'test'})

    def test_utf8_and_bom_survive_fragmented_decoding_without_unused_tail(self):
        import json
        response = {'id':'test', 'ok':True, 'result':'恢复 🧪'}
        payload = json.dumps(response, ensure_ascii=False).encode('utf-8')+b'\n'
        for wire in (payload, b'\xef\xbb\xbf'+payload):
            client = self.client([wire[i:i+1] for i in range(len(wire))])
            self.assertEqual(client._exchange({'id':'test'}), response)

    def test_extra_frame_carriage_return_and_duplicate_keys_refuse(self):
        from . import control
        cases = [b'{"id":"test","ok":true,"result":{}}\n{}\n',
                 b'{"id":"test","ok":true,"result":{}}\r\n',
                 b'{"id":"test","ok":true,"ok":false,"result":{}}\n',
                 b'{"id":"test","ok":true,"result":{"x":1,"x":2}}\n']
        for wire in cases:
            client=self.client([wire[:19],wire[19:]])
            with self.subTest(wire=wire), self.assertRaises(control.ControlError):
                client._exchange({'id':'test'})
            self.assertEqual(client.failure_evidence['receivedSha256'],hashlib.sha256(wire).hexdigest())

    def test_successive_responses_do_not_retain_previous_frame(self):
        import json
        responses=[{'id':str(i),'ok':True,'result':{'value':i}} for i in range(2)]
        client=self.client([json.dumps(row).encode()+b'\n' for row in responses])
        for row in responses:
            self.assertEqual(client._exchange({'id':row['id']}),row)

    def test_reader_version_change_refuses_old_instrument_comparison(self):
        old={'artifactReaderVersion':'bounded-json-v1','artifactPayloadBytes':128*1024*1024}
        new={**old,'artifactReaderVersion':artifact.READER_VERSION}
        self.assertFalse(compare.compare(scaled(document(a=1),old),scaled(document(a=1),new))['passed'])
        old.pop('artifactReaderVersion')
        self.assertFalse(compare.compare(scaled(document(a=1),old),scaled(document(a=1),new))['passed'])


class ArtifactClientLifetimeTests(unittest.TestCase):
    def test_context_exit_releases_the_instrument_without_waiting_for_gc(self):
        import weakref
        from . import control
        client=control.ControlClient('/fixture')
        client.configure_measurement(None,capture_failure=True)
        reference=weakref.ref(client)
        client.__exit__(None,None,None)
        del client
        self.assertIsNone(reference())

    def test_connection_renewal_still_refuses_expired_budget_before_sending(self):
        from . import control
        deadline=Mock(budget_seconds=600)
        deadline.remaining_seconds.return_value=-1
        client=control.ControlClient('/fixture')
        client.configure_measurement(deadline,capture_failure=True)
        client.close()  # Pagination renews a connection after 64 requests.
        socket=Mock()
        with patch.object(control.socket,'socket',return_value=socket):
            client.connect()
        with self.assertRaisesRegex(control.ControlError,'deadline'):
            client._exchange({'id':'test'})
        socket.sendall.assert_not_called()
        self.assertEqual(client.failure_evidence['budgetSeconds'],600)
        client.__exit__(None,None,None)

    def test_exceptional_context_exit_does_not_retain_the_client(self):
        import weakref
        from . import control
        class LocalClient(control.ControlClient):
            def connect(self):
                self._socket=Mock()
            def verify_contract(self):
                self._verified=True
        def use_client():
            client=LocalClient('/fixture')
            client.configure_measurement(None,capture_failure=True)
            reference=weakref.ref(client)
            try:
                with client:
                    raise ValueError('consumer failed')
            except ValueError:
                pass
            return reference
        self.assertIsNone(use_client()())

    def test_sixty_fifth_page_renews_and_reverifies_without_losing_content(self):
        from unittest.mock import MagicMock
        data=b'x'*65; expected=receipt(data); state={'reads':0,'verified':True}
        client=MagicMock();client.__enter__.return_value=client;client.failure_evidence=None
        def call(method,params):
            if not state['verified'] or state['reads']>=64:
                raise RuntimeError('connection requires renewal and contract verification')
            state['reads']+=1; offset=params['offset']
            result=page(b'x',offset,len(data));result['artifactDigest']=expected['artifactDigest']
            return result
        client.call.side_effect=call
        client.close.side_effect=lambda:state.update(verified=False)
        client.connect.side_effect=lambda:state.update(reads=0)
        client.verify_contract.side_effect=lambda:state.update(verified=True)
        runtime=Mock();runtime.client.return_value=client
        with patch.object(artifact,'RssSampler') as sampler:
            sampler.return_value.stop.return_value=[]
            _,proof=artifact.read_all(runtime,expected,len(data),lambda row:None)
        self.assertEqual(proof['actualPageCount'],65)
        self.assertEqual(proof['sha256'],hashlib.sha256(data).hexdigest())
