"""The measurements themselves, and the design rows they do and do not cover.

Design section I.2 lists thirteen metric rows (the IPC row is split into a
fixed-size and a paged leg).  This module measures the ones a macOS host can
measure honestly with no device attached and no UI lane, on either the Swift or
the Rust daemon, and declares every remaining row as a gap with the reason it
is blocked on that daemon.  A row is never silently dropped: an omission would
read as coverage.

Noise control follows the design's own prescription for the PR lane — each run
also times a fixed calibration workload, so a latency can be reported as a
ratio against work whose cost is known.  A ratio survives a runner that is
merely slower; an absolute number does not.
"""

from __future__ import annotations

import pathlib
import time

from . import baseline, clocks, control, harness, recovery, journal, artifact

# A pure-CPU workload with no allocation growth and no syscall, sized to land in
# the same millisecond range as the IPC round trips it normalises.
CALIBRATION_ITERATIONS = 60_000

# The soak fixture completes one cycle per restart interval, so this is what
# decides how many Jobs the seed leaves behind — not `--seed-jobs-per-cycle`
# alone.  The fixture's own default is 300 s, which would yield a single cycle.
SEED_RESTART_INTERVAL_SECONDS = 1

# An idle daemon holds its start-up working set for tens of seconds and then
# returns most of it in one step.  Measured on the reference host, the release
# has landed anywhere between 4 s and 29 s after start, and the plateau either
# side of it is flat to within a few kilobytes.  Percentiles taken across the
# step describe neither level, so the series is split at the release and each
# level is reported on its own.  A drop of at least this fraction of the
# running median is what counts as the release.
RESIDENT_SET_RELEASE_FRACTION = 0.25


def calibration_sample() -> float:
    started = clocks.awake_seconds()
    total = 0
    for index in range(CALIBRATION_ITERATIONS):
        total += index ^ (index >> 3)
    elapsed = clocks.awake_seconds() - started
    # Keep the optimiser honest about the loop's result.
    if total < 0:
        raise RuntimeError("calibration workload miscomputed")
    return elapsed * 1000.0


RECOVERY_METRIC_DEFINITIONS: dict[str, tuple[str, str, str]] = {
    "daemon.warmStartRecovery": (
        "milliseconds", "I.2 rows 2 and 7 (10k Journal recovery)",
        "spawn through verified clean replay marker and complete Job readback; includes verification",
    ),
    "daemon.warmStartRecovery.history": (
        "milliseconds", "I.2 rows 2 and 7 (10k terminal History restart)",
        "spawn through complete terminal History readback and zero recovery markers; includes verification",
    ),
}

METRIC_DEFINITIONS: dict[str, tuple[str, str, str]] = {
    # metric id -> (unit, design row, description)
    "daemon.coldStart": (
        "milliseconds",
        "I.2 row 1 (daemon cold start)",
        "process spawn through contract-verifying health handshake and explicit health response",
    ),
    "ipc.health": (
        "milliseconds",
        "I.2 row 4 (IPC request p50/p95/p99, UDS leg)",
        "health round trip on an established Unix domain socket connection",
    ),
    "ipc.jobList": (
        "milliseconds",
        "I.2 row 4 (IPC request p50/p95/p99, UDS leg)",
        "job.list round trip over a seeded Job store",
    ),
    "ipc.jobStatus": (
        "milliseconds",
        "I.2 row 4 (IPC request p50/p95/p99, UDS leg)",
        "job.status round trip for one terminal Job",
    ),
    "daemon.residentSetPlateau": (
        "bytes",
        "I.2 row 8 (idle resource footprint)",
        "resident set an idle daemon holds from start until it releases its "
        "start-up working set",
    ),
    "daemon.residentSetSteady": (
        "bytes",
        "I.2 row 8 (idle resource footprint)",
        "resident set an idle daemon holds after that release",
    ),
    "daemon.idleCpuPercent": (
        "percent",
        "I.2 row 8 (idle resource footprint)",
        "CPU share of a freshly started daemon as ps reports it, which is an "
        "average over the process lifetime rather than an instantaneous reading",
    ),
    "daemon.idleThreadCount": (
        "count",
        "I.2 row 8 (idle resource footprint)",
        "thread count of a freshly started daemon",
    ),
    "daemon.idleOpenFileDescriptorCount": (
        "count",
        "I.2 row 8 (idle resource footprint)",
        "open descriptors of a freshly started daemon",
    ),
    "calibration.busyLoop": (
        "milliseconds",
        "noise control (design section I.2, ratio-based PR gate)",
        "fixed CPU workload used as the ratio denominator",
    ),
}


RUNTIME_KINDS = ("swift", "rust")


def gap_definitions(runtime_kind: str = "swift") -> dict[str, baseline.Gap]:
    """Design rows this harness cannot measure on the given daemon, and why.

    Most reasons hold for both compositions. Runtime support does not imply
    that this harness measures it: the Rust owner now supports recovery and
    `job.reconcile`, but this read-only capture times neither. A reason that
    was true of an earlier protocol is not
    carried forward: a committed document that states it would be wrong.
    """

    if runtime_kind not in RUNTIME_KINDS:
        raise ValueError("runtime_kind must be swift or rust")
    rust = runtime_kind == "rust"
    gaps = {
        "daemon.warmStartRecovery": baseline.Gap(
            "daemon.warmStartRecovery",
            "I.2 rows 2 and 7 (warm start and 10k journal/history recovery)",
            (
                "JournalRecoveryContractTests in the Swift nightly slow lane "
                "time the Swift engine, not this daemon; Rust journal recovery "
                "and restart reconciliation are implemented; this capture does not "
                "time them unless --recovery-samples enables both 10k workloads"
            )
            if rust
            else (
                "measured today by JournalRecoveryContractTests under "
                "ARKDECK_RUN_LONG_JOURNAL_TESTS=1 in the nightly slow lane; the "
                "measurement exists but is neither archived nor comparable across "
                "runs, so no baseline value can be carried here yet"
            ),
            (
                "a timed Rust 10k recovery workload in this capture"
                if rust
                else "no cross-run archiving for the existing slow lane"
            ),
        ),
        "app.timeToInteractive": baseline.Gap(
            "app.timeToInteractive",
            "I.2 row 3 (App time to interactive)",
            "AppShellUITests asserts a connected device row before its 2s "
            "budget, so the measurement needs a real device and the UI lane",
            "device window and UI lane",
        ),
        "ipc.namedPipe": baseline.Gap(
            "ipc.namedPipe",
            "I.2 row 4 (IPC, named-pipe leg)",
            "the macOS capture uses Unix domain sockets and does not measure "
            "the Windows named-pipe transport",
            "a Windows performance capture with a named-pipe client",
        ),
        "ipc.xpc": baseline.Gap(
            "ipc.xpc",
            "I.2 row 4 (IPC, XPC leg)",
            "the XPC leg accepts only the signed App as its peer, and this "
            "harness is an unsigned Unix-domain-socket client; "
            "RuntimeXPCTransportCostTests publishes relative XPC cost only"
            + (
                "; the Rust daemon's XPC ingress is also opt-in "
                "(ARKDECK_APP_INGRESS=history)"
                if rust
                else ""
            ),
            "an absolute XPC measurement from a client the daemon accepts",
        ),
        "job.eventsWait": baseline.Gap(
            "job.eventsWait",
            "I.2 row 5 (job.events.wait idle CPU)",
            "job.events.wait is a proposal in design section F.2 and is not in "
            "the published single v1 method table; only the job.events pull "
            "page exists",
            "a registry, schema and client change that publishes job.events.wait",
        ),
        "job.journalAppend": baseline.Gap(
            "job.journalAppend",
            "I.2 row 5 (journal append per event)",
            "no leg times a durable journal append: this harness only reads, "
            "and the soak appends journals without timing them; the Swift "
            "per-event figure came from JournalRecoveryContractTests' opt-in "
            "journal benchmark, which times the Swift engine",
            "a timed durable-append leg over a 1,000-event Job",
        ),
        "job.eventsPage": baseline.Gap(
            "job.eventsPage",
            "I.2 row 5 (job.events 1,000-row page)",
            "job.events is published; the opt-in journal leg provides a 1000-event "
            "fixture, but the production 1 MiB page bound includes a per-row "
            "estimate and prevents a full 1000-row single page. job.eventsDrain "
            "measures complete multi-page readback, not this single-page budget",
            "a reviewed resolution of the single-page target versus production page bound",
        ),
        "artifact.pagedRead": baseline.Gap(
            "artifact.pagedRead",
            "I.2 row 6 (large artifact transfer, paged base64 leg)",
            "128 MiB InputArtifact paged read requires the opt-in artifact leg; "
            "1 GiB and 1 MiB are separately named scales. Ordinary Job Artifacts "
            "and copy counts are not established by an Import fixture",
            "a capture with --artifact-samples and a validated 128 MiB input",
        ),
        "artifact.copyCount": baseline.Gap(
            "artifact.copyCount", "I.2 large Artifact copies",
            "paged read validates bytes but does not instrument physical copies; sampled RSS is not a copy count",
            "copy instrumentation with a defined end-to-end boundary",
        ),
        "artifact.open": baseline.Gap(
            "artifact.open",
            "I.2 row 6 (large artifact transfer, zero-copy leg)",
            "artifact.open does not exist; whether to build it is itself one of "
            "the decisions section I.3 expects SPK-1 to unblock, so it cannot "
            "be baselined before it is decided",
            "a maintainer ruling on the zero-copy artifact path",
        ),
        "daemon.busyResources": baseline.Gap(
            "daemon.busyResources",
            "I.2 row 8 (busy resource footprint)",
            "the resource window samples an idle daemon only; a busy footprint "
            "needs a Golden Journey loop driving the daemon, and this harness "
            "is read-only by construction and submits no operation",
            "a harness leg that drives a Golden Journey loop on the isolated daemon",
        ),
        "job.cancelReconcile": baseline.Gap(
            "job.cancelReconcile",
            "I.2 row 9 (cancel and reconcile latency)",
            "the row times the cancellation of a running readOnly Job; this "
            "harness is read-only by construction and never submits the Job it "
            "would cancel, and the terminal leg needs an HDC child process on a "
            "real device"
            + (
                "; the Rust daemon supports job.reconcile, but this capture "
                "does not time a cancellation/reconciliation workload"
                if rust
                else ""
            ),
            (
                "a Rust harness leg that submits, cancels and reconciles a Job, "
                "and a device window"
                if rust
                else "a harness leg that submits and cancels a Job, and a device window"
            ),
        ),
        "viewer.scale": baseline.Gap(
            "viewer.scale",
            "I.2 row 10 (Viewer build, search, hit-test, scroll)",
            "build, search and hit-test are covered by the existing ratio gate "
            "in ViewerScalePerformanceTests, whose header refuses wall-clock "
            "budgets; the scroll leg needs the UI lane",
            "a maintainer ruling on wall-clock Viewer budgets, and the UI lane",
        ),
        "ui.frameResponse": baseline.Gap(
            "ui.frameResponse",
            "I.2 row 11 (UI frame response)",
            "needs the UI lane on both platforms",
            "UI lane",
        ),
        "package.size": baseline.Gap(
            "package.size",
            "I.2 row 12 (installer size and update delta)",
            "no DMG or MSIX producer exists in the repository, so there is no "
            "artefact to size",
            "TASK-XPA-022 (Windows packaging) and a macOS installer producer",
        ),
    }
    return gaps


class RunContext:
    """Executables and sample counts for one capture."""

    def __init__(
        self,
        *,
        daemon_executable: pathlib.Path,
        soak_executable: pathlib.Path,
        cold_start_samples: int,
        ipc_samples: int,
        idle_seconds: int,
        calibration_samples: int,
        seed_seconds: int,
        seed_jobs_per_cycle: int,
        runtime_kind: str = "swift",
        recovery_samples: int = 0,
        recovery_only: bool = False,
        recovery_require_quiet: bool = True,
        recovery_recorder=None,
        capture_recorder=None,
        require_quiet: bool = False,
        journal_samples: int = 0,
        journal_only: bool = False,
        artifact_samples: int = 0,
        artifact_only: bool = False,
        artifact_sizes: tuple[int, ...] = (128 * 1024 * 1024, 1024 * 1024 * 1024),
    ) -> None:
        if runtime_kind not in {"swift", "rust"}:
            raise ValueError("runtime_kind must be swift or rust")
        if recovery_samples < 0 or (recovery_only and recovery_samples == 0):
            raise ValueError("recovery-only requires positive recovery samples")
        if (recovery_only or recovery_samples) and runtime_kind != "rust":
            raise ValueError("recovery capture requires Rust")
        if journal_samples < 0 or (journal_only and not journal_samples):
            raise ValueError("journal-only requires positive journal samples")
        if (journal_samples and runtime_kind != "rust") or (journal_only and recovery_only):
            raise ValueError("journal capture requires Rust and separate only modes")
        if (artifact_samples < 0 or (artifact_only and not artifact_samples)
                or (artifact_samples and runtime_kind != "rust")
                or sum((artifact_only, journal_only, recovery_only)) > 1
                or not artifact_sizes or len(set(artifact_sizes)) != len(artifact_sizes)
                or any(size not in artifact.artifact_fixture.SIZES for size in artifact_sizes)):
            raise ValueError("invalid opt-in artifact workload")
        self.artifact_samples = artifact_samples
        self.artifact_only = artifact_only
        self.artifact_sizes = artifact_sizes
        self.journal_samples = journal_samples
        self.journal_only = journal_only
        self.recovery_samples = recovery_samples
        self.recovery_only = recovery_only
        self.recovery_require_quiet = recovery_require_quiet
        self.recovery_recorder = recovery_recorder
        self.capture_recorder = capture_recorder
        self.require_quiet = require_quiet
        self.runtime_kind = runtime_kind
        self.daemon_executable = daemon_executable
        self.soak_executable = soak_executable
        self.cold_start_samples = cold_start_samples
        self.ipc_samples = ipc_samples
        self.idle_seconds = idle_seconds
        self.calibration_samples = calibration_samples
        self.seed_seconds = seed_seconds
        self.seed_jobs_per_cycle = seed_jobs_per_cycle


class RunFailed(RuntimeError):
    """One measurement run could not complete."""


JOB_LIST_PAGE_SIZE = 50
# Three requests per iteration plus handshake fit the 128-frame connection.
IPC_SAMPLES_PER_CONNECTION = 32


def split_at_release(
    samples: list[float], fraction: float = RESIDENT_SET_RELEASE_FRACTION
) -> tuple[list[float], list[float], int | None]:
    """Split a resident-set series at its largest qualifying downward step.

    Returns `(plateau, steady, index)`.  With no qualifying step the whole
    series remains the plateau, steady is empty, and the index is `None`.
    No observation of a release means no measurement of the post-release phase.
    """

    best_index: int | None = None
    best_drop = 0.0
    for index in range(1, len(samples)):
        previous = samples[index - 1]
        drop = previous - samples[index]
        if previous > 0 and drop / previous >= fraction and drop > best_drop:
            best_drop = drop
            best_index = index
    if best_index is None:
        return list(samples), [], None
    return samples[:best_index], samples[best_index:], best_index


def _job_store_probe(client: control.ControlClient) -> tuple[str | None, int | None]:
    """Return one Job id and the number of rows the projection returned.

    The row count is what every per-row figure for `job.list` divides by, so it
    is read back and recorded rather than inferred from the seed parameters: the
    seed produces a different number of Jobs depending on the fixture's restart
    interval, and a reader of the baseline document cannot reconstruct it.
    """

    result = client.call("job.list", {"pageSize": JOB_LIST_PAGE_SIZE})
    if not isinstance(result, dict):
        return None, None
    items = result.get("items")
    if not isinstance(items, list):
        return None, None
    job_id: str | None = None
    for item in items:
        if isinstance(item, dict) and isinstance(item.get("jobId"), str):
            job_id = item["jobId"]
            break
    return job_id, len(items)


def execute_run(
    context: RunContext, state_directory: pathlib.Path
) -> tuple[dict[str, list[float]], dict[str, object]]:
    """Take every measurable sample once, against one isolated Runtime.

    Returns the samples and the data scale they were taken at.  A budget only
    holds at the scale it was measured at, so the scale travels with the
    numbers instead of being reconstructed from the seed parameters.
    """

    samples: dict[str, list[float]] = {name: [] for name in (METRIC_DEFINITIONS | RECOVERY_METRIC_DEFINITIONS | journal.DEFINITIONS | artifact.DEFINITIONS)}
    scale: dict[str, object] = {
        "seedSeconds": context.seed_seconds,
        "seedJobsPerCycle": context.seed_jobs_per_cycle,
        "seedRestartIntervalSeconds": SEED_RESTART_INTERVAL_SECONDS,
        "jobListPageSize": JOB_LIST_PAGE_SIZE,
        "jobStoreRowCount": None,
        "ipcSamplesPerConnection": IPC_SAMPLES_PER_CONNECTION,
    }

    def record(entry):
        if context.capture_recorder:
            context.capture_recorder(entry)

    def guard(phase):
        if context.require_quiet:
            record({"kind": "quietHost", "phase": phase, **recovery.assert_quiet_host()})

    guard("run-start")
    for _ in range(context.calibration_samples):
        samples["calibration.busyLoop"].append(calibration_sample())

    if context.recovery_samples:
        scale["recoveryFixtureVersion"] = recovery.VERSION
        scale["recoveryJournalEventCount"] = recovery.COUNT
        scale["recoveryHistoryJobCount"] = recovery.COUNT
        scale["recoveryPageSize"] = recovery.PAGE_SIZE
        scale["recoveryTimingBoundary"] = "spawn-through-completion-verification-v1"
        scale["recoverySamples"] = []
        scale["recoverySeedStrategy"] = "pristine-template-per-run-v1"
        with recovery.FixtureSet(context.soak_executable) as fixtures:
            for sample_index in range(context.recovery_samples):
                for workload, name in recovery.METRICS.items():
                    try:
                        quiet = recovery.assert_quiet_host() if context.recovery_require_quiet else {"waived": True}
                        elapsed, evidence = recovery.measure(
                            context.daemon_executable, context.soak_executable, workload,
                            require_quiet=context.recovery_require_quiet,
                            fixture=fixtures.get(workload),
                        )
                    except Exception as error:
                        if context.recovery_recorder:
                            context.recovery_recorder({**getattr(error, "sample", {}), "workload": workload, "sampleIndex": sample_index, "status": "FAILED", "errorType": type(error).__name__})
                        raise
                    samples[name].append(elapsed)
                    evidence["sampleIndex"] = sample_index
                    evidence["quietHostBeforeSample"] = quiet
                    scale["recoverySamples"].append(evidence)
                    if context.recovery_recorder:
                        context.recovery_recorder({"status": "MEASURED", **evidence})
    if context.journal_samples:
        scale["journalSamples"] = []
        for sample_index in range(context.journal_samples):
            def journal_record(entry):
                record({"leg": "journal", "sampleIndex": sample_index, **entry})
            measured, facts = journal.measure(context.daemon_executable, context.soak_executable,
                                              journal_record, context.require_quiet)
            for name, values in measured.items():
                samples[name].extend(values)
            scale["journalSamples"].append(facts.pop("journalEvidence"))
            scale.update(facts)
    if context.artifact_samples:
        scale["artifactSamples"] = []
        scale["artifactMetricScales"] = {}
        for sample_index in range(context.artifact_samples):
            for size in context.artifact_sizes:
                def artifact_record(entry):
                    record({"leg": "artifact", "sampleIndex": sample_index, "payloadBytes": size, **entry})
                elapsed, facts = artifact.measure(context.daemon_executable, context.soak_executable,
                                                  size, artifact_record, context.require_quiet)
                name = artifact.metric_id(size)
                samples[name].append(elapsed)
                scale["artifactSamples"].append(facts.pop("artifactEvidence"))
                scale["artifactMetricScales"][name] = facts
    if context.recovery_only or context.journal_only or context.artifact_only:
        return {name: values for name, values in samples.items() if values}, scale

    seeded = harness.seed_state_directory(
        context.soak_executable,
        state_directory,
        context.seed_seconds,
        context.seed_jobs_per_cycle,
        SEED_RESTART_INTERVAL_SECONDS,
    )
    if seeded.returncode != 0:
        raise RunFailed(
            "the soak fixture could not seed a Runtime state directory: "
            f"{seeded.stdout.strip()} {seeded.stderr.strip()}"
        )

    runtime = harness.IsolatedRuntime(
        context.daemon_executable, state_directory, runtime_kind=context.runtime_kind
    )
    try:
        # Cold start is measured by repeatedly restarting the daemon on the
        # same populated state directory, which is what design section I.2
        # describes.  Every start is paired with a stop so that each sample is a
        # genuine cold start rather than the first one plus a long-lived server.
        for sample_index in range(context.cold_start_samples):
            guard("cold-start-before")
            try:
                elapsed = runtime.start()
            except Exception as error:
                record({"kind": "coldStart", "sampleIndex": sample_index,
                        "status": "FAILED", "errorType": type(error).__name__,
                        "diagnostics": runtime.start_diagnostics})
                raise
            samples["daemon.coldStart"].append(elapsed * 1000.0)
            record({"kind": "coldStart", "sampleIndex": sample_index,
                    "status": "MEASURED", "milliseconds": elapsed * 1000.0,
                    "diagnostics": runtime.start_diagnostics})
            runtime.stop()
            guard("cold-start-after")

        guard("ipc-before")

        runtime.start()
        with runtime.client() as client:
            job_id, row_count = _job_store_probe(client)
            if job_id is None or row_count is None or row_count <= 0:
                raise RunFailed(
                    "the measured daemon cannot read the soak seed's Jobs; "
                    "use matching Runtime and soak executables"
                )
            scale["jobStoreRowCount"] = row_count
            for index in range(context.ipc_samples):
                if index and index % IPC_SAMPLES_PER_CONNECTION == 0:
                    client.close()
                    client.connect()
                    client.verify_contract()
                _, elapsed = client.timed_call("health")
                samples["ipc.health"].append(elapsed * 1000.0)
                _, elapsed = client.timed_call(
                    "job.list", {"pageSize": JOB_LIST_PAGE_SIZE}
                )
                samples["ipc.jobList"].append(elapsed * 1000.0)
                if job_id is not None:
                    _, elapsed = client.timed_call("job.status", {"jobId": job_id})
                    samples["ipc.jobStatus"].append(elapsed * 1000.0)
        runtime.stop()

        guard("ipc-after")

        # The resource window needs a daemon that has served nothing but its own
        # health check.  Sampling the process that just answered thousands of
        # requests measures a served-then-quiet resident set, and calling that
        # "idle" flatters nothing — it inflates the number, which is the wrong
        # direction for arguing about headroom under a ceiling.
        runtime.start()
        if runtime.process is None:
            raise RunFailed("the daemon stopped before the idle window")
        pid = runtime.process.pid
        resident_series: list[float] = []
        resident_times: list[float] = []
        resource_started = clocks.awake_seconds()
        scale["residentSetPhaseMethod"] = "observed-release-v2"
        scale["idleWindowSeconds"] = context.idle_seconds
        idle_deadline = clocks.Deadline(max(1, context.idle_seconds))
        while not idle_deadline.expired():
            # One sample per second: the resource readers shell out, and
            # sampling as fast as they return would make the harness itself the
            # busiest thing on an otherwise idle host.
            time.sleep(1.0)
            guard("idle-sample-before")
            sample_started = clocks.awake_seconds() - resource_started
            sample = harness.sample_process_resources(pid)
            elapsed = clocks.awake_seconds() - resource_started
            record({"kind": "idleResources", "startedAtSeconds": sample_started,
                    "finishedAtSeconds": elapsed, **sample.as_document()})
            if sample.resident_set_bytes is not None:
                resident_series.append(float(sample.resident_set_bytes))
                resident_times.append(sample_started)
            if sample.cpu_percent is not None:
                samples["daemon.idleCpuPercent"].append(sample.cpu_percent)
            if sample.thread_count is not None:
                samples["daemon.idleThreadCount"].append(float(sample.thread_count))
            if sample.open_file_descriptor_count is not None:
                samples["daemon.idleOpenFileDescriptorCount"].append(
                    float(sample.open_file_descriptor_count)
                )
        plateau, steady, release_index = split_at_release(resident_series)
        samples["daemon.residentSetPlateau"] = plateau
        samples["daemon.residentSetSteady"] = steady
        scale["residentSetReleaseObserved"] = release_index is not None
        scale["residentSetReleaseAtSeconds"] = (
            resident_times[release_index] if release_index is not None else None
        )
        scale["residentSetRawSamples"] = [
            {"elapsedSeconds": elapsed, "bytes": value}
            for elapsed, value in zip(resident_times, resident_series)
        ]
        if not steady:
            scale["unmeasured"] = {"daemon.residentSetSteady":
                "no qualifying release observed in the fixed idle window; post-release RSS is not measured"}
        guard("idle-after")
        scale["residentSetSampleCount"] = len(resident_series)
    finally:
        runtime.stop()

    return {name: values for name, values in samples.items() if values}, scale
